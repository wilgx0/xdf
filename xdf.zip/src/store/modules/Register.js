import types from '../types.js'
import axios from 'axios'

const state ={
	registerShow : false,
}

const getters = {
	registerShow(state){
		return state.registerShow;
	}
}

const actions = {
	show_register({commit}){
		commit(types.SHOW_RIGISTER);
	},
	hide_register({commit}){
		commit(types.HIDE_RIGISTER)
	}
}

const mutations = {
	[types.SHOW_RIGISTER](state){
		state.registerShow = true;
	},
	[types.HIDE_RIGISTER](state){
		state.registerShow = false;
	},
}

export default {
	state,
	getters,
	actions,
	mutations,
}
