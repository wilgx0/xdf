<template>
  <div class='login'>
  	<mt-header fixed title="新东方"></mt-header>
  	<h1>用户登录</h1>
  	<p>
  		  <mt-field label="用户名" placeholder="请输入用户名" v-model="username"></mt-field>
				<mt-field label="密码" placeholder="请输入密码" type="password" v-model="pwd"></mt-field>
  	</p>
 
		<p>
			<mt-button type="primary" size="large" @click="login">登  录</mt-button>
		</p>
		
		<p>
			<mt-button type="default" size="large" @click="show_register">注册新用户</mt-button>
		</p>
		
		<Register></Register>
  </div>
</template>

<script>
import Register from './Register.vue'
import { Toast, MessageBox } from 'mint-ui'

export default {
  data () {
    return {
    	username:'',
    	pwd:'',
    }
  },
  methods:{
  	login(){
			var _this = this;
			let postData = _this.$qs.stringify({
				username: _this.username,
				pwd:_this.pwd,
			});
			_this.$http({
				method: 'post',
				url: _this.$url + '/Api/place/login',
				data: postData,
			}).then(function(response) {
				
			}).catch(function(error) {
				console.log(error);
			})
  	},
  	show_register(){
  		this.$store.dispatch('show_register');
  	}
  },
  components:{
  	Register,
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.login{
	padding-top:50px;
}
</style>
