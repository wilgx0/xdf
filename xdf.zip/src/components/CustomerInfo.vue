<template>
	<div class='main'>
		<p>
			<mt-field label="客户名称" placeholder="请输入客户名称" ></mt-field>
	
			<mt-field label="客户电话" placeholder="请输入客户电话" ></mt-field>	
	
			<mt-field label="微信号" placeholder="请输入微信号" ></mt-field>	
	
			<mt-field label="意向国家" placeholder="请输入意向国家" ></mt-field>	
			
			<mt-field label="备注" placeholder="备注" type="textarea" rows="4"></mt-field>
		</p>
	</div>
</template>

<script>
	
	//客户信息
	export default{
		data(){
			return {
				
			}
		}
	}
</script>

<style>
</style>