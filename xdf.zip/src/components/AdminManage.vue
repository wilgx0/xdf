<template>
	<div class='main'>
		<p>
			<mt-button type="primary" size="large">渠道商注册信息查看</mt-button>
		</p>
		
		<p>
			<mt-button type="primary" size="large">客户信息查看</mt-button>	
		</p>
		
		<p>
			<mt-button type="primary" size="large">设置渠道商返佣比例</mt-button>	
		</p>
		
		<p>
			<mt-button type="primary" size="large">信息统计</mt-button>	
		</p>
	</div>
</template>

<script>
	export default{
		data(){
			return {
				
			}
		}
	}
</script>

<style>
</style>