<template>
	<div class='main'>
		
		<p>
			<mt-field label="渠道名称" placeholder="请输入渠道名称" ></mt-field>
	
			<mt-field label="联系方式" placeholder="请输入联系方式" ></mt-field>	
	
			<mt-field label="个人账号" placeholder="请输入个人账号" ></mt-field>	
	
			<mt-field label="公司账号" placeholder="请输入公司账号" ></mt-field>	
			
			
			
		
		</p>
		
	</div>
</template>

<script>
	//渠道信息
	export default{
		data(){
			return {
			}
		}
	}
</script>

<style>
</style>